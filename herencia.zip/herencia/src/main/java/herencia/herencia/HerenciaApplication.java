package herencia.herencia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HerenciaApplication {

	public static void main(String[] args) {
		SpringApplication.run(HerenciaApplication.class, args);
	}

}
